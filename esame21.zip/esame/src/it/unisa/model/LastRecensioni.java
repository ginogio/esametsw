package it.unisa.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

public class LastRecensioni {
	
private ArrayList<Recensione> lipro=new ArrayList<Recensione>();
	
	public LastRecensioni() {
		
	}
	
	public ArrayList<Recensione> getLast() throws SQLException
	{
		int codes = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Collection<Recensione> products = new LinkedList<Recensione>();
		//Stringa di selezione dal database
		String selectSQL = "SELECT * FROM recensioni";
		
		//Controllo se il parametro order � valido e, in tal caso, eseguo l'ordinamento direttamente dal database
		
		//Mi serve per rilasciare sicuramente le risorse
		try {
			//Istanzio una connessione usando il mio DriverManager
			connection = DriverManagerConnectionPool.getConnection();
			//Preparo lo statement
			preparedStatement = connection.prepareStatement(selectSQL);
			
			System.out.println("doRetrieveAll: " + preparedStatement.toString());
			
			//Eseguo il preparedStatement e ne salvo l'output
			ResultSet rs = preparedStatement.executeQuery();
			
			//Visito tupla per tupla la risposta
			while(rs.next()) {
				codes=rs.getInt("code");
			}
			//Stringa di selezione parametrica dal database
			String selectSQLl = "SELECT * FROM recensioni WHERE CODE = ?";
			
			//Mi serve per rilasciare sicuramente le risorse
			for(int i=0;i<4;i++)
			{
				Recensione bean = new Recensione();
				try {
					//Istanzio una connessione usando il mio DriverManager
					connection = DriverManagerConnectionPool.getConnection();
					//Preparo lo statement
					preparedStatement = connection.prepareStatement(selectSQLl);
					preparedStatement.setInt(1, codes);
					
					//System.out.println("doRetrieveByKey: " + preparedStatement.toString());
					
					//Eseguo il preparedStatement e ne salvo l'output anche se so che l'output � uno solo
					ResultSet rss = preparedStatement.executeQuery();
					
					//Visito la risposta col while anche se so che avr� un unico valore, lo faccio per sicurezza
					while(rss.next()) {
						//Setto tutti i parametri
						bean.setCode(rss.getInt("code"));
						bean.setId_utente(rss.getInt("id_utente"));
						bean.setId_product(rss.getInt("id_product"));
						bean.setNomeut(rss.getString("nomeut"));
						bean.setTitolo(rss.getString("titolo"));
						bean.setDescrizione(rss.getString("description"));
						bean.setStelle(rss.getInt("stelle"));
					}
					codes--;
					lipro.add(bean);
				}finally {
					
				}
			}
		}finally {
			try {
				//Rilascio il preparedStatement
				if(preparedStatement != null)
					preparedStatement.close();
			} finally {
				//Se rilascio fuori dal try finally pi� interno la connessione se venisse lanciata un'eccezione
				//dalla chiusura di preparedStatement la connessione non verrebbe rilasciata
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		return lipro;
	}

}
