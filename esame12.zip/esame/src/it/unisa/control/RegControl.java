package it.unisa.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.unisa.model.DriverManagerConnectionPool;
import it.unisa.model.UtenteRegistrato;

/**
 * Servlet implementation class RegControl
 */
@WebServlet("/RegControl")
public class RegControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public RegControl() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		String insertSQL="INSERT INTO utente "+ " (NAME,COGNOME,EMAIL,INDIRIZZO,CITTA,UTENTE,PASSWORD) "+ " VALUES (?, ?, ?, ?,?,?,?)";
		UtenteRegistrato ur=new UtenteRegistrato();
		ur.setNome(request.getParameter("name"));
		ur.setCognome(request.getParameter("cognome"));
		ur.setIndirizzo(request.getParameter("indirizzo"));
		ur.setCitta(request.getParameter("citta"));
		ur.setEmail(request.getParameter("email"));
		ur.setUtente(request.getParameter("username"));
		ur.setPassword(request.getParameter("password"));
		try {
				connection=DriverManagerConnectionPool.getConnection();
				preparedStatement=connection.prepareStatement(insertSQL);
				preparedStatement.setString(1,ur.getNome());
				preparedStatement.setString(2,ur.getCognome());
				preparedStatement.setString(3,ur.getEmail());
				preparedStatement.setString(4,ur.getIndirizzo());
				preparedStatement.setString(5,ur.getCitta());
				preparedStatement.setString(6,ur.getUtente());
				preparedStatement.setString(7,ur.getPassword());
				
				System.out.println("doSave: "+preparedStatement.toString());
				preparedStatement.executeUpdate();
				
				connection.commit();
				response.sendRedirect("loginsucc.jsp");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally //uso il try solo per il finally, cos� da rilasciare tutte le risorse
		{
			try { //potrebbe esserci un eccezione alla preparedstatement riguardante la connessione
			if(preparedStatement != null)
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
			try {
				DriverManagerConnectionPool.releaseConnection(connection);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}

	}

}
