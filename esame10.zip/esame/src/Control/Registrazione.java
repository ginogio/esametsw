package Control;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Registrazione")
public class Registrazione extends HttpServlet {
		private static final long serialVersionUID = 1L;
	       
	    public Registrazione() {
	        super();
	        
	    }

		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			String error="";
			String nome=request.getParameter("nome");
			String cognome=request.getParameter("cognome");
			String indirizzo=request.getParameter("indirizzo");
			String citta=request.getParameter("citta");
			String email=request.getParameter("email");
			String username=request.getParameter("username");
			
			
			//trim crea una copia della stringa senza spazi all'inizio e alla fine
			if(nome==null || nome.trim().equals("")) {
				error+="Inserisci nome <br>";
			}else {
				request.setAttribute("nome",nome);
			}
			
			if(cognome==null || cognome.trim().equals("")) {
				error+="Inserisci cognome <br>";
			}else {
				request.setAttribute("cognome",cognome);
			}
			
			if(indirizzo==null || indirizzo.trim().equals("")) {
				error+="Inserisci indirizzo <br>";
			}else {
				request.setAttribute("indirizzo",indirizzo);
			}
			
			if(citta==null || citta.trim().equals("")) {
				error+="Inserisci citt� <br>";
			}else {
				request.setAttribute("citta",citta);
			}
			
			if(email==null || email.trim().equals("")) {
				error+="Inserisci nome <br>";
			}else {
				request.setAttribute("email",email);
			}
			
			if(username==null || username.trim().equals("")) {
				error+="Inserisci username <br>";
			}else {
				request.setAttribute("username",username);
			}
			
			
			//collega la servlet alla pagina jsp
			RequestDispatcher dispatcher=getServletContext().getRequestDispatcher("/registrazione.jsp");
			dispatcher.forward(request, response);
		}


		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request, response);
		}

	}


