/**
 * 
 */
function allLetter(uname)
{
	var letters = /^[A-Za-z]+$/;
	if(uname.value.match(letters))
	{
		return true;
	}
	else
	{
		alert('Username must have alphabet characters only');
		uname.focus();
		return false;
	}
}

function alphanumeric(uadd)
{
var letters = /^[0-9a-zA-Z]+$/;
if(uadd.value.match(letters))
{
return true;
}
else
{
alert("User address must have alphanumeric characters only");
uadd.focus();
return false;
}

	function checkNamesurname(inputtxt){
		var name=/^[A-Za-z]+$/;
		if(inputtxt.value.match(name))
			return true;
		alert("Errore1");
		return false;
	}
	
	function checkEmail(inputtxt){
		var email=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		if(inputtxt.value.match(email))
			return true;
		alert("Errore2");
		return false;
	}
	
	function checkPhonenumber(inputtxt){
		var phoneno=/^([0-9]{3}-[0-9]{7})$/;
		if(inputtxt.value.match(phoneno))
		return true;
		alert("Errore3");
		return false
	}
	
	function validate(obj){
		var valid=true;
		var name=document.getElementsByName("name")[0];
		if(!checkNamesurname(name)){
			valid=false;
			name.classList.add("error");
		}else{
			name.classList.remove("error");
		}
		
		var surname=document.getElementsByName("cognome")[0];
		if(!checkNamesurname(surname)){
			valid=false;
			surname.classList.add("error");
		}else{
			surname.classList.remove("error");
		}
		
		var email=document.getElementsByName("email")[0];
		if(!checkEmail(email)){
			valid=false;
			email.classList.add("error");
		}else{
			email.classList.remove("error");
		}
		if(valid)obj.submit();
	}
	