package it.unisa.model;

import java.io.Serializable;
//E' il Bean che rappresenta la tabella Product del database
public class ProductBean implements Serializable {
	
	private static final long serialVersionUID = 100L;
	
	private int code;
	private String name;
	private String description;
	private int price;
	private int quantity;
	
	public ProductBean() {
		this.setCode(-1);
		this.setName("");
		this.setDescription("");
		this.setPrice(0);
		this.setQuantity(0);
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	@Override
	public boolean equals(Object o) {
		if(o == null)
			return false;
		if(o.getClass() != getClass())
			return false;
		
		if(this.getCode() == ((ProductBean)o).getCode())
			return true;
		else
			return false;
	}
	
	@Override
	public String toString() {
		return name + " (" + code + "), " + price + ", " + quantity + ", " + description; 
	}
}
