package it.unisa.control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.unisa.model.Cart;
import it.unisa.model.ProductBean;
import it.unisa.model.ProductModelDM;

@WebServlet("/ProductControl")
//Servlet che gestisce la richiesta dei prodotti ProductBean
public class ProductControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//Statica perch� mi serve uguale per tutti
	private static ProductModelDM model = new ProductModelDM();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Cart <ProductBean> cart=(Cart<ProductBean>) request.getSession().getAttribute("carrello");
		
		if(cart==null) {
			cart=new Cart<ProductBean>();
			request.getSession().setAttribute("carrello",cart);
		}
		
		//Controllo l'azione da eseguire poich� vari bottoni possono richiamare la servlet
		String action = request.getParameter("action");
		
		try {
			if(action != null) {
				if(action.equalsIgnoreCase("insert")) {
					String name = request.getParameter("name");
					String description = request.getParameter("description");
					int price = Integer.parseInt(request.getParameter("price"));
					int quantity = Integer.parseInt(request.getParameter("quantity"));
					
					ProductBean bean = new ProductBean();
					bean.setName(name);
					bean.setDescription(description);
					bean.setPrice(price);
					bean.setQuantity(quantity);
					
					//chiamo la doSave per salvare il prodotto nel DB
					model.doSave(bean);
				}
				//controllo se � stato chiesto alla Servlet di fornire i dettagli di un prodotto con l'id specificato nella request
				else if(action.equalsIgnoreCase("details")) {
					int id = Integer.parseInt(request.getParameter("id"));
					
					//mando alla JSP il bean di cui deve leggere le informazioni
					request.setAttribute("product", model.doRetrieveByKey(id));
				}
				else if(action.equalsIgnoreCase("update")) {
					int id = Integer.parseInt(request.getParameter("id"));
					String name = request.getParameter("name");
					String description = request.getParameter("description");
					int price = Integer.parseInt(request.getParameter("price"));
					int quantity = Integer.parseInt(request.getParameter("quantity"));
					ProductBean bean = new ProductBean();
					
					bean.setCode(id);
					bean.setName(name);
					bean.setDescription(description);
					bean.setPrice(price);
					bean.setQuantity(quantity);
					
					model.doUpdate(bean);
				} else if(action.equalsIgnoreCase("delete")) {
					int id=Integer.parseInt(request.getParameter("id"));
					model.doRetrieveByKey(id);
					ProductBean bean= model.doRetrieveByKey(id);
					if(bean!=null)
						model.doDelete(bean);
				} else if(action.equalsIgnoreCase("addCart")) {
					int id=Integer.parseInt(request.getParameter("id"));
					ProductBean bean=model.doRetrieveByKey(id);
					if(bean!=null)
						cart.addItem(bean);
				} else if (action.equalsIgnoreCase("deleteCart")) {
					int id=Integer.parseInt(request.getParameter("id"));
					ProductBean bean=model.doRetrieveByKey(id);
					if(bean!=null)
						cart.deleteItem(bean);
				} else if(action.equalsIgnoreCase("clearCart"))
					cart.deteleAll();
			}
		} catch (SQLException | NumberFormatException e) {
			//Stampo l'errore in console
			System.out.println("Error: " + e.getMessage());
			//imposto nella request l'errore, in modo da avvertire l'utente
			request.setAttribute("error", e.getMessage());
		}
		
		request.getSession().setAttribute("carrello",cart);
		request.setAttribute("cart",cart);
		
		//controllo se la JSP ha richiesto un particolare ordinamento
		String sort = request.getParameter("sort");
		
		try {
			//prima di scrivere l'attributo lo elimino, in modo tale da non avere problemi
			request.removeAttribute("products");
			//salvo nella request la collezione di prodotti ordinata in base alla richiesta della JSP
			request.setAttribute("products", model.doRetrieveAll(sort));
		} catch (SQLException e) {
			//Stampo l'errore in console
			System.out.println("Error: " + e.getMessage());
			//imposto nella request l'errore, in modo da avvertire l'utente
			request.setAttribute("error", e.getMessage());
		}
		//Imposto il dispacher
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/ProductView.jsp");
		//Chiamo il forward perch� non ho modificato la response, ma solo la request
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
