package it.unisa.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;

public class ModelAdm implements ProductModel<AdminRegistrato> {

	@Override
	public AdminRegistrato doRetrieveByKey(int code) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<AdminRegistrato> doRetrieveAll(String order) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void doSave(AdminRegistrato product) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doUpdate(AdminRegistrato ar) throws SQLException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		
		String updateSQL="UPDATE admins SET"+" name=?, cognome=?, email=?, utente=?, password=?  "+" WHERE utente = ?";
		try {
				connection=DriverManagerConnectionPool.getConnection();
				preparedStatement=connection.prepareStatement(updateSQL);
				
				preparedStatement.setString(1,ar.getNome());
				preparedStatement.setString(2,ar.getCognome());
				preparedStatement.setString(3,ar.getEmail());
				preparedStatement.setString(4,ar.getUtente());
				preparedStatement.setString(5, ar.getPassword());
				preparedStatement.setString(6,ar.getUtente());
				System.out.println("doUpdate: "+preparedStatement.toString());
				preparedStatement.executeUpdate();
				
				connection.commit();

		}
		finally //uso il try solo per il finally, cos� da rilasciare tutte le risorse
		{
			try { //potrebbe esserci un eccezione alla preparedstatement riguardante la connessione
			if(preparedStatement != null)
				preparedStatement.close();
			}finally {
			DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
	}

	@Override
	public boolean doDelete(AdminRegistrato product) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

}
