package it.unisa.control;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import it.unisa.model.Cart;
import it.unisa.model.ProductBean;
import it.unisa.model.ProductModelDM;

@WebServlet("/ProductControl")
@MultipartConfig(fileSizeThreshold=1024*1024*2,
maxFileSize=1024*1024*10,
maxRequestSize=1024*1024*50)
//Servlet che gestisce la richiesta dei prodotti ProductBean
public class ProductControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//Statica perch� mi serve uguale per tutti
	private static ProductModelDM model = new ProductModelDM();
	private static PhotoControl pc=new PhotoControl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	ArrayList<ProductBean> prodotti= new ArrayList<ProductBean>();
		Cart <ProductBean> cart=(Cart<ProductBean>) request.getSession().getAttribute("carrello");
		
		if(cart==null) {
			cart=new Cart<ProductBean>();
			request.getSession().setAttribute("carrello",cart);
		}
		
		//Controllo l'azione da eseguire poich� vari bottoni possono richiamare la servlet
		String action = request.getParameter("action");
		System.out.println(action);
		String names=request.getParameter("name");
		System.out.println(names);
		
		try {
			if(action != null) {
				if(action.equalsIgnoreCase("insert")) {
					String name = request.getParameter("name");
					String description = request.getParameter("descrizione");
					String type= request.getParameter("tipo");
					float price = Float.parseFloat(request.getParameter("prezzo"));
					int quantity = Integer.parseInt(request.getParameter("quantita"));
					Part filePart=request.getPart("foto");
					System.out.println(description);
					InputStream is=filePart.getInputStream();
					byte[] bytes=is.readAllBytes();
					
					ProductBean bean = new ProductBean();
					bean.setName(name);
					bean.setDescription(description);
					bean.SetType(type);
					bean.setPrice(price);
					bean.setQuantity(quantity);
					bean.setFoto(bytes);
					
					//chiamo la doSave per salvare il prodotto nel DB
					model.doSave(bean);
					prodotti.add(bean);
					request.getSession().setAttribute("prodotti", prodotti);
				}
				//controllo se � stato chiesto alla Servlet di fornire i dettagli di un prodotto con l'id specificato nella request
				else if(action.equalsIgnoreCase("details")) {
					int id = Integer.parseInt(request.getParameter("id"));
					
					//mando alla JSP il bean di cui deve leggere le informazioni
					request.setAttribute("product", model.doRetrieveByKey(id));
				}
				else if(action.equalsIgnoreCase("update")) {
					int id = Integer.parseInt(request.getParameter("id"));
					String name = request.getParameter("name");
					String description = request.getParameter("description");
					float price = Float.parseFloat(request.getParameter("price"));
					int quantity = Integer.parseInt(request.getParameter("quantity"));
					Part filePart=request.getPart("foto");
					System.out.println(description);
					InputStream is=filePart.getInputStream();
					byte[] bytes=is.readAllBytes();
					ProductBean bean = new ProductBean();
					
					bean.setCode(id);
					bean.setName(name);
					bean.setDescription(description);
					bean.setPrice(price);
					bean.setQuantity(quantity);
					bean.setFoto(bytes);
					
					model.doUpdate(bean);
				} else if(action.equalsIgnoreCase("delete")) {
					int id=Integer.parseInt(request.getParameter("id"));
					model.doRetrieveByKey(id);
					ProductBean bean= model.doRetrieveByKey(id);
					if(bean!=null)
						model.doDelete(bean);
				} else if(action.equalsIgnoreCase("addCart")) {
					int id=Integer.parseInt(request.getParameter("id"));
					ProductBean bean=model.doRetrieveByKey(id);
					bean.setQuantity(1);
					float price=bean.getPrice();
					if(bean!=null)
					{
						boolean ch=false;
						List<ProductBean>lp=cart.getItems();
						for(ProductBean pb:lp)
						{	
							if(pb.getCode()==id)
							{
								int q=pb.getQuantity();
								pb.setQuantity(q+1);
								pb.setPrice(price+pb.getPrice());
								request.getSession().setAttribute("cart", cart);
								ch=true;
							}
						}
						if(!ch)
						{
							cart.addItem(bean);
							request.getSession().setAttribute("cart", cart);
						}
					}
				} else if (action.equalsIgnoreCase("deleteCart")) {
					int id=Integer.parseInt(request.getParameter("id"));
					ProductBean bean=model.doRetrieveByKey(id);
					Cart <ProductBean> cartt=(Cart<ProductBean>) request.getSession().getAttribute("carrello");
					List<ProductBean>lp=cartt.getItems();
					if(cartt!=null)
					{
						for(ProductBean pb:lp)
						{	
							if(pb.getCode()==id)
							{
								lp.remove(pb);
								request.getSession().setAttribute("cart", cartt);break;
							}
						}
					}
					response.sendRedirect("/esame/carrello.jsp");
					return;
				} else if(action.equalsIgnoreCase("clearCart"))
				{
					cart.deteleAll();
					response.sendRedirect("/esame/carrello.jsp");
					return;
				}
			}
		} catch (SQLException | NumberFormatException e) {
			//Stampo l'errore in console
			System.out.println("Error: " + e.getMessage());
			//imposto nella request l'errore, in modo da avvertire l'utente
			request.setAttribute("error", e.getMessage());
		}
		
		request.getSession().setAttribute("carrello",cart);
		request.setAttribute("cart",cart);
		
		//controllo se la JSP ha richiesto un particolare ordinamento
		String sort = request.getParameter("sort");
		
		try {
			//prima di scrivere l'attributo lo elimino, in modo tale da non avere problemi
			request.removeAttribute("products");
			//salvo nella request la collezione di prodotti ordinata in base alla richiesta della JSP
			request.setAttribute("products", model.doRetrieveAll(sort));
		} catch (SQLException e) {
			//Stampo l'errore in console
			System.out.println("Error: " + e.getMessage());
			//imposto nella request l'errore, in modo da avvertire l'utente
			request.setAttribute("error", e.getMessage());
		}
		//Imposto il dispacher
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/catalogo.jsp");
		//Chiamo il forward perch� non ho modificato la response, ma solo la request
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
