package it.unisa.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.LinkedList;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;

//DM sta per driver manager
//Classe che implementa l'interfaccia ProductModel per la classe ProductBean
public class ProductModelDM implements ProductModel<ProductBean> {
	@Override
	//Permette di recuperare uno specifico prodotto fornendo l'id
	public ProductBean doRetrieveByKey(int code) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		//Bean da restituire in output
		ProductBean bean = new ProductBean();
		//Stringa di selezione parametrica dal database
		String selectSQL = "SELECT * FROM product WHERE CODE = ?";
		
		//Mi serve per rilasciare sicuramente le risorse
		try {
			//Istanzio una connessione usando il mio DriverManager
			connection = DriverManagerConnectionPool.getConnection();
			//Preparo lo statement
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, code);
			
			System.out.println("doRetrieveByKey: " + preparedStatement.toString());
			
			//Eseguo il preparedStatement e ne salvo l'output anche se so che l'output � uno solo
			ResultSet rs = preparedStatement.executeQuery();
			
			//Visito la risposta col while anche se so che avr� un unico valore, lo faccio per sicurezza
			while(rs.next()) {
				//Setto tutti i parametri
				bean.setCode(rs.getInt("code"));
				bean.setName(rs.getString("name"));
				bean.setDescription(rs.getString("description"));
				bean.SetType(rs.getString("tipo"));
				bean.setPrice(rs.getFloat("price"));
				bean.setQuantity(rs.getInt("quantity"));
				bean.setFoto(rs.getBytes("foto"));
			}	
		} finally {
			try {
				//Rilascio il preparedStatement
				if(preparedStatement != null)
					preparedStatement.close();
			} finally {
				//Se rilascio fuori dal try finally pi� interno la connessione se venisse lanciata un'eccezione
				//dalla chiusura di preparedStatement la connessione non verrebbe rilasciata
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return bean;
	}

	@Override
	//Ci permette di recuperare tutti i prodotti dalla tabella product in un ordine specifico
	public Collection<ProductBean> doRetrieveAll(String order) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Collection<ProductBean> products = new LinkedList<ProductBean>();
		//Stringa di selezione dal database
		String selectSQL = "SELECT * FROM product";
		
		//Controllo se il parametro order � valido e, in tal caso, eseguo l'ordinamento direttamente dal database
		if(order != null && !order.equals(""))
			selectSQL += " ORDER BY " + order;
		
		//Mi serve per rilasciare sicuramente le risorse
		try {
			//Istanzio una connessione usando il mio DriverManager
			connection = DriverManagerConnectionPool.getConnection();
			//Preparo lo statement
			preparedStatement = connection.prepareStatement(selectSQL);
			
			System.out.println("doRetrieveAll: " + preparedStatement.toString());
			
			//Eseguo il preparedStatement e ne salvo l'output
			ResultSet rs = preparedStatement.executeQuery();
			
			//Visito tupla per tupla la risposta
			while(rs.next()) {
				ProductBean bean = new ProductBean();
				//Setto tutti i parametri
				bean.setCode(rs.getInt("code"));
				bean.setName(rs.getString("name"));
				bean.setDescription(rs.getString("description"));
				bean.SetType(rs.getString("tipo"));
				bean.setPrice(rs.getFloat("price"));
				bean.setQuantity(rs.getInt("quantity"));
				bean.setFoto(rs.getBytes("foto"));
				
				//Aggiungo il bean che ho appena creato alla Collezione
				products.add(bean);
			}	
		} finally {
			try {
				//Rilascio il preparedStatement
				if(preparedStatement != null)
					preparedStatement.close();
			} finally {
				//Se rilascio fuori dal try finally pi� interno la connessione se venisse lanciata un'eccezione
				//dalla chiusura di preparedStatement la connessione non verrebbe rilasciata
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return products;
	}

	@Override
	//Aggiunge un prodotto al DB
	public void doSave(ProductBean product) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		//Stringa di inserimento parametrica dal database
		//Non inserisco a mano code perch� � un int autoincrement
		String selectSQL = "INSERT INTO product (name, description, tipo,price, quantity,foto) VALUES (?, ?, ?, ?,?,?)";
		
		/*Stringa per provare a generare un'errore
		 String selectSQL = "INSERT INTO product2 (name, description, price, quantity) VALUES (?, ?, ?, ?)";
		 */

		//Mi serve per rilasciare sicuramente le risorse
		try {
			//Istanzio una connessione usando il mio DriverManager
			connection = DriverManagerConnectionPool.getConnection();
			//Preparo lo statement
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1, product.getName());
			preparedStatement.setString(2, product.getDescription());
			preparedStatement.setString(3,product.getType());
			preparedStatement.setFloat(4, product.getPrice());
			preparedStatement.setInt(5, product.getQuantity());
			preparedStatement.setBytes(6, product.getFoto());
			
			System.out.println("doSave: " + preparedStatement.toString());
			
			//Eseguo il preparedStatement inserendo i dati all'interno del database
			preparedStatement.executeUpdate();
			//rendo effettivo l'inserimento (azione necessaria perch� ho settato l'autocommit a false nel driver manager)
			connection.commit();
		} finally {
			try {
				//Rilascio il preparedStatement
				if(preparedStatement != null)
					preparedStatement.close();
			} finally {
				//Se rilascio fuori dal try finally pi� interno la connessione se venisse lanciata un'eccezione
				//dalla chiusura di preparedStatement la connessione non verrebbe rilasciata
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}
	}

	@Override
	public void doUpdate(ProductBean product) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		//Stringa di inserimento parametrica dal database
		//Non inserisco a mano code perch� � un int autoincrement
		String updateSQL = "UPDATE product SET name = ?, description = ?, price = ?, quantity = ?, foto=? WHERE code = ?";

		//Mi serve per rilasciare sicuramente le risorse
		try {
			//Istanzio una connessione usando il mio DriverManager
			connection = DriverManagerConnectionPool.getConnection();
			//Preparo lo statement
			preparedStatement = connection.prepareStatement(updateSQL);
			preparedStatement.setString(1, product.getName());
			preparedStatement.setString(2, product.getDescription());
			preparedStatement.setFloat(3, product.getPrice());
			preparedStatement.setInt(4, product.getQuantity());
			preparedStatement.setBytes(5, product.getFoto());
			preparedStatement.setInt(6, product.getCode());
			
			System.out.println("doUpdate: " + preparedStatement.toString());
			
			//Eseguo il preparedStatement inserendo i dati all'interno del database
			preparedStatement.executeUpdate();
			//rendo effettivo l'update (azione necessaria perch� ho settato l'autocommit a false nel driver manager)
			connection.commit();
		} finally {
			try {
				//Rilascio il preparedStatement
				if(preparedStatement != null)
					preparedStatement.close();
			} finally {
				//Se rilascio fuori dal try finally pi� interno la connessione se venisse lanciata un'eccezione
				//dalla chiusura di preparedStatement la connessione non verrebbe rilasciata
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			}
	}

	@Override
	public boolean doDelete(ProductBean product) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int result=0;
		String deleteSql="DELETE FROM product WHERE CODE=?";
		try {
			connection= DriverManagerConnectionPool.getConnection();
			preparedStatement= connection.prepareStatement(deleteSql);
			preparedStatement.setInt(1,product.getCode());
			System.out.println("doDelete: "+ preparedStatement.toString());
			result= preparedStatement.executeUpdate();
			connection.commit();
		}finally {
			try {
				//Rilascio il preparedStatement
				if(preparedStatement != null)
					preparedStatement.close();
			} finally {
				//Se rilascio fuori dal try finally pi� interno la connessione se venisse lanciata un'eccezione
				//dalla chiusura di preparedStatement la connessione non verrebbe rilasciata
					DriverManagerConnectionPool.releaseConnection(connection);
				}
			
		}
		return (result!=0);
	}
	
	public Collection<ProductBean> doRetrieveType(String order,String ordine) throws SQLException {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		Collection<ProductBean> products = new LinkedList<ProductBean>();
		//Stringa di selezione dal database
		String selectSQL = "SELECT * FROM product WHERE tipo = ?";
		if(ordine != null && !ordine.equals(""))
			selectSQL += " ORDER BY " + ordine;
		//Controllo se il parametro order � valido e, in tal caso, eseguo l'ordinamento direttamente dal database
		
		//Mi serve per rilasciare sicuramente le risorse
		try {
			//Istanzio una connessione usando il mio DriverManager
			connection = DriverManagerConnectionPool.getConnection();
			//Preparo lo statement
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setString(1,order);
			
			System.out.println("doRetrieveAll: " + preparedStatement.toString());
			
			//Eseguo il preparedStatement e ne salvo l'output
			ResultSet rs = preparedStatement.executeQuery();
			
			//Visito tupla per tupla la risposta
			while(rs.next()) {
				ProductBean bean = new ProductBean();
				//Setto tutti i parametri
				bean.setCode(rs.getInt("code"));
				bean.setName(rs.getString("name"));
				bean.setDescription(rs.getString("description"));
				bean.SetType(rs.getString("tipo"));
				bean.setPrice(rs.getFloat("price"));
				bean.setQuantity(rs.getInt("quantity"));
				bean.setFoto(rs.getBytes("foto"));
				
				//Aggiungo il bean che ho appena creato alla Collezione
				products.add(bean);
			}	
		} finally {
			try {
				//Rilascio il preparedStatement
				if(preparedStatement != null)
					preparedStatement.close();
			} finally {
				//Se rilascio fuori dal try finally pi� interno la connessione se venisse lanciata un'eccezione
				//dalla chiusura di preparedStatement la connessione non verrebbe rilasciata
				DriverManagerConnectionPool.releaseConnection(connection);
			}
		}
		
		return products;
	}
}
