package it.unisa.control;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.unisa.model.AdminRegistrato;
import it.unisa.model.DriverManagerConnectionPool;
import it.unisa.model.ProductBean;
import it.unisa.model.ProductBuy;
import it.unisa.model.UtenteRegistrato;
import javafx.scene.control.RadioButton;

/**
 * Servlet implementation class LogControl
 */
@WebServlet("/LogControl")
public class LogControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogControl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String utc=request.getParameter("sceltaP");
		if(utc.equals("Utente"))
		{
			UtenteRegistrato ur= new UtenteRegistrato();
			ur.setUtente(request.getParameter("username"));
			ur.setPassword(request.getParameter("password"));
			boolean logged=false;
			Connection connection=null;
			PreparedStatement preparedStatement=null;
			String selectSQL="SELECT * FROM utente ";
			try
			{
				connection=DriverManagerConnectionPool.getConnection();//Istanzia da 0 una connessione oppure ne usa gi� usata precedentemente
				preparedStatement=connection.prepareStatement(selectSQL);
				
				System.out.println("doRetrieveAll: "+preparedStatement.toString());
				ResultSet rs=preparedStatement.executeQuery();
				while(rs.next())
				{
					UtenteRegistrato ur1= new UtenteRegistrato();
					ur1.setUtente(rs.getString("utente"));
					ur1.setPassword(rs.getString("password"));
					ur1.setCitta(rs.getString("citta"));
					ur1.setCognome(rs.getString("cognome"));
					ur1.setEmail(rs.getString("email"));
					ur1.setIndirizzo(rs.getString("indirizzo"));
					ur1.setNome(rs.getString("name"));
					System.out.println(ur.getUtente()+"-"+ur.getPassword()+"----"+ur1.getUtente()+"-"+ur1.getPassword());
					if((ur.getUtente().equals(ur1.getUtente())) && (ur.getPassword().equals(ur1.getPassword())))
							{
								ur.setCitta(ur1.getCitta());
								ur.setEmail(ur1.getEmail());
								ur.setIndirizzo(ur1.getIndirizzo());
								ur.setNome(ur1.getNome());
								ur.setCognome(ur1.getCognome());
								System.out.println("Login Effettuato con successo");
								logged=true;
								request.getSession().setAttribute("utente",ur);
								response.sendRedirect("loginsucc.jsp");
							}
				}
				if(!logged)
				{
					response.sendRedirect("loginerror.html");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally //uso il try solo per il finally, cos� da rilasciare tutte le risorse
			{
				try { //potrebbe esserci un eccezione alla preparedstatement riguardante la connessione
				if(preparedStatement != null)
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
				try {
					DriverManagerConnectionPool.releaseConnection(connection);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
			}
		}
		if(utc.equals("Admin"))
		{
			AdminRegistrato ar= new AdminRegistrato();
			ar.setUtente(request.getParameter("username"));
			ar.setPassword(request.getParameter("password"));
			boolean logged=false;
			Connection connection=null;
			PreparedStatement preparedStatement=null;
			String selectSQL="SELECT * FROM admins ";
			try
			{
				connection=DriverManagerConnectionPool.getConnection();//Istanzia da 0 una connessione oppure ne usa gi� usata precedentemente
				preparedStatement=connection.prepareStatement(selectSQL);
				
				System.out.println("doRetrieveAll: "+preparedStatement.toString());
				ResultSet rs=preparedStatement.executeQuery();
				while(rs.next())
				{
					AdminRegistrato ar1= new AdminRegistrato();
					ar1.setUtente(rs.getString("utente"));
					ar1.setPassword(rs.getString("password"));
					ar1.setEmail(rs.getString("email"));
					ar1.setNome(rs.getString("name"));
					ar1.setCognome(rs.getString("cognome"));
					System.out.println(ar.getUtente()+"-"+ar.getPassword()+"----"+ar1.getUtente()+"-"+ar1.getPassword());
					if((ar.getUtente().equals(ar1.getUtente())) && (ar.getPassword().equals(ar1.getPassword())))
							{
								ar.setEmail(ar1.getEmail());
								ar.setNome(ar1.getNome());
								ar.setCognome(ar1.getCognome());
								System.out.println("Login Effettuato con successo");
								logged=true;
								request.getSession().setAttribute("admin",ar);
								response.sendRedirect("loginsucc.jsp");
							}
				}
				if(!logged)
				{
					response.sendRedirect("loginerror.html");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally //uso il try solo per il finally, cos� da rilasciare tutte le risorse
			{
				try { //potrebbe esserci un eccezione alla preparedstatement riguardante la connessione
				if(preparedStatement != null)
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
				try {
					DriverManagerConnectionPool.releaseConnection(connection);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
			}
		}
	}

}
